
import './App.css';
import Notes from './Maincomponent/Notes';
function App() {
  return (
    <div className="App">
 <Notes/>
    </div>
  );
}

export default App;
